import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/recipe_model.dart';
import '../config/app_constants.dart';

/// AI service for recipe generation using Groq API
class AIService {
  /// Generate recipe from ingredients using Groq API
  Future<List<RecipeModel>> generateRecipes({
    required String ingredients,
    required String userId,
    String timeFilter = '15-30 min',
    int count = 3,
  }) async {
    try {
      // Validate API key
      if (AppConstants.GROQ_API_KEY == 'GROQ_API_KEY_HERE') {
        throw Exception(
            'Please set your Groq API key in config/app_constants.dart');
      }

      // Build AI prompt
      final String prompt = _buildPrompt(ingredients, timeFilter, count);

      // Make API request
      final response = await http.post(
        Uri.parse(AppConstants.GROQ_API_URL),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${AppConstants.GROQ_API_KEY}',
        },
        body: jsonEncode({
          'model': AppConstants.GROQ_MODEL,
          'messages': [
            {
              'role': 'system',
              'content': 'You are a professional chef assistant that generates recipes in valid JSON format only. Never include any text before or after the JSON. '
                  'CRITICAL: You must ALWAYS compute missing ingredients by comparing the recipe ingredients against the user-provided ingredients. '
                  'Never assume pantry items like salt, oil, spices, or butter unless the user explicitly provided them. '
                  'If the user provides limited ingredients (e.g., 1-2 items), the missing ingredients list must be substantial. '
                  'The missingIngredients field must NEVER be empty or null. Every ingredient not in the user input MUST be listed as missing.',
            },
            {
              'role': 'user',
              'content': prompt,
            }
          ],
          'temperature': 0.7,
          'max_tokens': 2000,
        }),
      );

      if (response.statusCode != 200) {
        throw Exception(
            'API request failed with status: ${response.statusCode}\n${response.body}');
      }

      // Parse response
      final Map<String, dynamic> responseData = jsonDecode(response.body);
      final String aiResponse =
          responseData['choices'][0]['message']['content'];

      // Extract JSON from response
      final List<RecipeModel> recipes = _parseAIResponse(aiResponse, userId);

      if (recipes.isEmpty) {
        throw Exception('Failed to generate recipes. Please try again.');
      }

      return recipes;
    } catch (e) {
      throw Exception('Recipe generation failed: ${e.toString()}');
    }
  }

  /// Build AI prompt for recipe generation
  String _buildPrompt(String ingredients, String timeFilter, int count) {
    return '''
Generate $count unique and creative recipes using these ingredients: $ingredients

User-Provided Ingredients (these are the ONLY ones available):
$ingredients

CRITICAL INSTRUCTIONS:
1. Compare required recipe ingredients against user-provided ingredients ABOVE
2. Any ingredient NOT in the user input MUST appear in missingIngredients
3. Never assume pantry items (salt, oil, butter, spices, etc.) - if user didn't provide them, list them as missing
4. missingIngredients must NEVER be empty or null
5. If user provides limited ingredients, the missing list must be large and complete

Requirements:
- Preparation time should be around $timeFilter
- Each recipe must be realistic and practical
- Include exact measurements for all ingredients
- Clearly distinguish between user-provided and missing ingredients
- Provide detailed step-by-step instructions
- Estimate accurate nutrition values

Respond ONLY with a JSON array of recipes. No explanatory text before or after.

Format:
[
  {
    "recipeName": "Creative Recipe Name",
    "prepTime": "15 minutes",
    "cookTime": "10 minutes",
    "difficulty": "Easy",
    "ingredients": [
      "chicken breast - 200g",
      "rice - 1 cup",
      "tomatoes - 2 medium",
      "olive oil - 2 tbsp",
      "salt - to taste",
      "pepper - to taste"
    ],
    "missingIngredients": [
      "olive oil",
      "salt",
      "pepper"
    ],
    "instructions": [
      "Wash and cut the chicken into small pieces",
      "Heat oil in a pan over medium heat",
      "Add chicken and cook for 5-7 minutes"
    ],
    "calories": 450,
    "protein": "35g",
    "carbs": "48g",
    "fats": "12g",
    "category": "Healthy"
  }
]
''';
  }

  /// Parse AI response and convert to RecipeModel list
  List<RecipeModel> _parseAIResponse(String aiResponse, String userId) {
    try {
      // Clean the response
      String cleanedResponse = aiResponse.trim();

      // Remove markdown code blocks if present
      cleanedResponse = cleanedResponse
          .replaceAll('```json', '')
          .replaceAll('```', '')
          .trim();

      // Try to find JSON array
      final int startIndex = cleanedResponse.indexOf('[');
      final int endIndex = cleanedResponse.lastIndexOf(']');

      if (startIndex == -1 || endIndex == -1) {
        throw Exception('No valid JSON array found in response');
      }

      final String jsonString =
          cleanedResponse.substring(startIndex, endIndex + 1);
      final dynamic parsed = jsonDecode(jsonString);

      if (parsed is! List) {
        throw Exception('Response is not a JSON array');
      }

      final List<RecipeModel> recipes = [];
      for (final recipeJson in parsed) {
        if (recipeJson is Map<String, dynamic>) {
          recipes.add(RecipeModel.fromJson(recipeJson, userId));
        }
      }

      return recipes;
    } catch (e) {
      // Fallback: try to parse as single object
      try {
        String cleanedResponse = aiResponse.trim();
        cleanedResponse = cleanedResponse
            .replaceAll('```json', '')
            .replaceAll('```', '')
            .trim();

        final int startIndex = cleanedResponse.indexOf('{');
        final int endIndex = cleanedResponse.lastIndexOf('}');

        if (startIndex != -1 && endIndex != -1) {
          final String jsonString =
              cleanedResponse.substring(startIndex, endIndex + 1);
          final dynamic parsed = jsonDecode(jsonString);

          if (parsed is Map<String, dynamic>) {
            return [RecipeModel.fromJson(parsed, userId)];
          }
        }
      } catch (_) {}

      throw Exception('Failed to parse AI response: ${e.toString()}');
    }
  }

  /// Generate nutrition estimate for custom recipe
  Future<Map<String, dynamic>> estimateNutrition({
    required List<String> ingredients,
  }) async {
    try {
      if (AppConstants.GROQ_API_KEY ==
          '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') {
        throw Exception('Please set your Groq API key');
      }

      final response = await http.post(
        Uri.parse(AppConstants.GROQ_API_URL),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${AppConstants.GROQ_API_KEY}',
        },
        body: jsonEncode({
          'model': AppConstants.GROQ_MODEL,
          'messages': [
            {
              'role': 'system',
              'content':
                  'You are a nutrition expert. Respond only in JSON format.',
            },
            {
              'role': 'user',
              'content': '''
Estimate nutrition for a recipe with these ingredients: ${ingredients.join(', ')}

Respond ONLY with JSON:
{
  "calories": 400,
  "protein": "25g",
  "carbs": "45g",
  "fats": "15g"
}
''',
            }
          ],
          'temperature': 0.5,
          'max_tokens': 200,
        }),
      );

      if (response.statusCode != 200) {
        throw Exception('API request failed');
      }

      final Map<String, dynamic> responseData = jsonDecode(response.body);
      final String aiResponse =
          responseData['choices'][0]['message']['content'];

      final cleanedResponse =
          aiResponse.replaceAll('```json', '').replaceAll('```', '').trim();

      return jsonDecode(cleanedResponse);
    } catch (e) {
      // Return default values on error
      return {
        'calories': 0,
        'protein': '0g',
        'carbs': '0g',
        'fats': '0g',
      };
    }
  }

  /// Suggest recipe modifications based on dietary preferences
  Future<String> suggestModifications({
    required String recipeName,
    required String dietaryPreference,
  }) async {
    try {
      if (AppConstants.GROQ_API_KEY == 'GROQ_API_KEY_HERE') {
        throw Exception('Please set your Groq API key');
      }

      final response = await http.post(
        Uri.parse(AppConstants.GROQ_API_URL),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${AppConstants.GROQ_API_KEY}',
        },
        body: jsonEncode({
          'model': AppConstants.GROQ_MODEL,
          'messages': [
            {
              'role': 'user',
              'content': '''
Suggest modifications to make "$recipeName" suitable for a $dietaryPreference diet.
Provide 3-5 specific, practical suggestions in a concise list format.
''',
            }
          ],
          'temperature': 0.7,
          'max_tokens': 300,
        }),
      );

      if (response.statusCode != 200) {
        throw Exception('API request failed');
      }

      final Map<String, dynamic> responseData = jsonDecode(response.body);
      return responseData['choices'][0]['message']['content'];
    } catch (e) {
      return 'Unable to generate suggestions at this time.';
    }
  }
}
