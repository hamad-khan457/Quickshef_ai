/// Global application constants and configuration values
/// Used across the entire app for consistency and easy maintenance
class AppConstants {
  // ⚠️ PRIVATE CONSTRUCTOR - Prevents instantiation
  AppConstants._();

  // ===== API CONFIGURATION =====
  /// Groq API Key - NEVER hardcode production keys
  /// Use environment variables or secure key management in production
  /// This is a PLACEHOLDER - Replace with your actual Groq API key from environment
  static const String GROQ_API_KEY =
      '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';

  /// Groq API endpoint for LLaMA model
  static const String GROQ_API_URL =
      'https://api.groq.com/openai/v1/chat/completions';

  /// Groq model identifier
  static const String GROQ_MODEL = 'llama-3.1-8b-instant';

  // ===== SHARED PREFERENCES KEYS =====
  /// Key for storing first launch status
  static const String PREF_IS_FIRST_LAUNCH = 'is_first_launch';

  /// Key for storing theme preference
  static const String PREF_THEME_MODE = 'theme_mode';

  /// Key for storing user dietary preferences
  static const String PREF_DIETARY_PREFERENCE = 'dietary_preference';

  /// Key for storing saved recipes count
  static const String PREF_SAVED_RECIPES_COUNT = 'saved_recipes_count';

  // ===== UI DIMENSION CONSTANTS =====
  /// Standard border radius for cards and buttons
  static const double borderRadius = 16.0;

  /// Large border radius for containers
  static const double borderRadiusLarge = 20.0;

  /// Small border radius for chips
  static const double borderRadiusSmall = 8.0;

  /// Standard padding for screens
  static const double screenPadding = 24.0;

  /// Standard padding for cards
  static const double cardPadding = 16.0;

  /// Standard gap between elements
  static const double standardGap = 16.0;

  /// Small gap between elements
  static const double smallGap = 8.0;

  /// Large gap between sections
  static const double largeGap = 32.0;

  /// Standard card elevation
  static const double cardElevation = 2.0;

  /// Button height
  static const double buttonHeight = 56.0;

  /// Small button height
  static const double buttonHeightSmall = 40.0;

  // ===== ANIMATION DURATIONS =====
  /// Splash screen display duration
  static const Duration splashDuration = Duration(milliseconds: 2000);

  /// Standard animation duration
  static const Duration animationDuration = Duration(milliseconds: 300);

  /// Fast animation duration
  static const Duration fastAnimationDuration = Duration(milliseconds: 150);

  /// Slow animation duration
  static const Duration slowAnimationDuration = Duration(milliseconds: 500);

  /// Page transition duration
  static const Duration pageTransitionDuration = Duration(milliseconds: 400);

  // ===== FORM VALIDATION CONSTANTS =====
  /// Minimum password length
  static const int minPasswordLength = 6;

  /// Maximum name length
  static const int maxNameLength = 100;

  /// Maximum ingredients input length
  static const int maxIngredientsLength = 500;

  // ===== RECIPE GENERATION CONSTANTS =====
  /// Default number of recipes to generate
  static const int defaultRecipeCount = 3;

  /// Maximum number of recipes to generate
  static const int maxRecipeCount = 5;

  /// AI temperature for recipe generation (0.0 - 1.0)
  /// Lower = more deterministic, Higher = more creative
  static const double aiTemperature = 0.7;

  /// Maximum tokens for AI response
  static const int maxAITokens = 2000;

  /// Default prep time filter
  static const String defaultPrepTimeFilter = '15-30 min';

  /// List of time filter options (for compatibility)
  static const List<String> timeFilters = [
    prepTime10_15,
    prepTime15_30,
    prepTime30_45,
    prepTime45Plus,
  ];

  /// Recipe categories list (for compatibility)
  static const List<String> recipeCategories = [
    categoryQuickMeals,
    categoryHealthy,
    categoryBudget,
    categoryPopular,
  ];

  // ===== VERSION INFORMATION =====
  /// App version
  static const String appVersion = '1.0.0';

  /// Minimum supported app version
  static const String minimumAppVersion = '1.0.0';

  // ===== ERROR MESSAGES =====
  /// Generic error message
  static const String errorGeneric = 'An error occurred. Please try again.';

  /// Network error message
  static const String errorNetwork =
      'Network error. Please check your internet connection.';

  /// Authentication error message
  static const String errorAuth = 'Authentication failed. Please try again.';

  /// Invalid email error
  static const String errorInvalidEmail = 'Please enter a valid email address.';

  /// Password too short error
  static const String errorPasswordShort =
      'Password must be at least $minPasswordLength characters.';

  /// Password mismatch error
  static const String errorPasswordMismatch = 'Passwords do not match.';

  /// Empty ingredients error
  static const String errorEmptyIngredients =
      'Please enter at least one ingredient.';

  /// No recipes generated error
  static const String errorNoRecipes =
      'Could not generate recipes. Please try again.';

  /// Recipe save error
  static const String errorSaveRecipe = 'Failed to save recipe.';

  /// Recipe delete error
  static const String errorDeleteRecipe = 'Failed to delete recipe.';

  /// Empty name error
  static const String errorEmptyName = 'Please enter your name.';

  /// Empty email error
  static const String errorEmptyEmail = 'Please enter your email.';

  /// Empty password error
  static const String errorEmptyPassword = 'Please enter your password.';

  /// Weak password error
  static const String errorWeakPassword =
      'Password must be at least $minPasswordLength characters.';

  // ===== SUCCESS MESSAGES =====
  /// Login success message
  static const String successLoginComplete = 'Login successful!';

  /// Registration success message
  static const String successRegistrationComplete =
      'Account created successfully!';

  /// Account created success message
  static const String successAccountCreated = 'Account created successfully!';

  /// Recipe saved success message
  static const String successRecipeSaved = 'Recipe saved successfully!';

  /// Recipe deleted success message
  static const String successRecipeDeleted = 'Recipe deleted!';

  /// Items added to shopping list
  static const String successAddedToShoppingList = 'Added to shopping list!';

  /// Profile updated success message
  static const String successProfileUpdated = 'Profile updated!';

  /// Data cleared success message
  static const String successDataCleared = 'Data cleared!';

  // ===== VALIDATION MESSAGES =====
  /// Email required message
  static const String validationEmailRequired = 'Email is required.';

  /// Name required message
  static const String validationNameRequired = 'Name is required.';

  /// Password required message
  static const String validationPasswordRequired = 'Password is required.';

  // ===== UI STRINGS =====
  /// App name
  static const String appName = 'QuickChef AI';

  /// App tagline
  static const String appTagline = 'Your Smart Kitchen Buddy';

  /// Home screen greeting
  static const String homeGreeting = "Hi, what's in your kitchen today?";

  /// Generate recipes button text
  static const String btnGenerateRecipes = 'Generate Recipes';

  /// Save recipe button text
  static const String btnSaveRecipe = 'Save Recipe';

  /// Delete recipe button text
  static const String btnDeleteRecipe = 'Delete';

  /// Add to shopping list button text
  static const String btnAddToShoppingList = 'Add to Shopping List';

  /// Login button text
  static const String btnLogin = 'Login';

  /// Register button text
  static const String btnRegister = 'Create Account';

  /// Logout button text
  static const String btnLogout = 'Logout';

  /// Skip button text
  static const String btnSkip = 'Skip';

  /// Get started button text
  static const String btnGetStarted = 'Get Started';

  // ===== RECIPE CATEGORIES =====
  /// Quick meals category
  static const String categoryQuickMeals = 'Quick Meals';

  /// Healthy options category
  static const String categoryHealthy = 'Healthy Options';

  /// Budget friendly category
  static const String categoryBudget = 'Budget Recipes';

  /// Popular category
  static const String categoryPopular = 'Popular Choices';

  // ===== DIFFICULTY LEVELS =====
  /// Easy difficulty
  static const String difficultyEasy = 'Easy';

  /// Medium difficulty
  static const String difficultyMedium = 'Medium';

  /// Hard difficulty
  static const String difficultyHard = 'Hard';

  // ===== PREP TIME OPTIONS =====
  /// 10-15 minutes
  static const String prepTime10_15 = '10-15 min';

  /// 15-30 minutes
  static const String prepTime15_30 = '15-30 min';

  /// 30-45 minutes
  static const String prepTime30_45 = '30-45 min';

  /// 45+ minutes
  static const String prepTime45Plus = '45+ min';

  /// List of all prep time options
  static const List<String> prepTimeOptions = [
    prepTime10_15,
    prepTime15_30,
    prepTime30_45,
    prepTime45Plus,
  ];

  // ===== DIETARY PREFERENCES =====
  /// Vegetarian diet
  static const String dietaryVegetarian = 'Vegetarian';

  /// Vegan diet
  static const String dietaryVegan = 'Vegan';

  /// Non-vegetarian diet
  static const String dietaryNonVegetarian = 'Non-Vegetarian';

  /// Gluten-free diet
  static const String dietaryGlutenFree = 'Gluten-Free';

  /// List of dietary preferences
  static const List<String> dietaryPreferences = [
    dietaryNonVegetarian,
    dietaryVegetarian,
    dietaryVegan,
    dietaryGlutenFree,
  ];

  // ===== FIRESTORE COLLECTION NAMES =====
  /// Users collection name
  static const String firestoreUsers = 'users';

  /// Saved recipes collection name
  static const String firestoreSavedRecipes = 'saved_recipes';

  /// Shopping list collection name
  static const String firestoreShoppingList = 'shopping_list';

  // COLLECTION NAME ALIASES (for compatibility with existing code)
  /// Users collection (alias)
  static const String COLLECTION_USERS = firestoreUsers;

  /// Saved recipes collection (alias)
  static const String COLLECTION_RECIPES = firestoreSavedRecipes;

  /// Shopping list collection (alias)
  static const String COLLECTION_SHOPPING_LIST = firestoreShoppingList;

  // ===== NUMERIC CONSTANTS =====
  /// Default recipe generation timeout (seconds)
  static const int recipeGenerationTimeout = 30;

  /// Firestore pagination limit
  static const int firestorePaginationLimit = 20;

  /// Minimum calories for a recipe
  static const int minCalories = 100;

  /// Maximum calories for a recipe
  static const int maxCalories = 3000;

  // ===== REGEX PATTERNS =====
  /// Email validation pattern
  static const String emailPattern =
      r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';

  /// URL validation pattern
  static const String urlPattern =
      r'^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&/=]*)$';
}
