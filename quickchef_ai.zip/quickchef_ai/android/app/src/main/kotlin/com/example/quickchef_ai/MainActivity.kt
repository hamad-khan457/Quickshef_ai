package com.example.quickchef_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
